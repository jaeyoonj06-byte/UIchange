import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import HomeFootprint from "./pages/HomeFootprint.jsx";
import StartPage from "./pages/StartPage.jsx";
import SimpleInputPage from "./pages/SimpleInputPage.jsx";
import ResultPage from "./pages/ResultPage.jsx";
import MethodPage from "./pages/MethodPage.jsx";
import AccountPage from "./pages/AccountPage.jsx";
import HistoryPage from "./pages/HistoryPage.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomeFootprint />} />
        <Route path="calculator" element={<StartPage />} />
        <Route path="calculator/simple" element={<SimpleInputPage />} />
        <Route path="result" element={<ResultPage />} />
        <Route path="result/:id" element={<ResultPage />} />
        <Route path="method" element={<MethodPage />} />
        <Route path="account" element={<AccountPage />} />
        <Route path="account/history" element={<HistoryPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
